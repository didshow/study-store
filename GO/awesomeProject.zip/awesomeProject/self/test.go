package main

import "fmt"

func main() {
	slice := []int{1, 2}
	fmt.Println(&slice)
}
