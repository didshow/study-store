package main

import (
	"fmt"
)

type Node struct {
	Val  int
	Next *Node
}

func (node *Node) Jose(n int, m int) []int {
	res := make([]int, 0)
	head := &Node{Val: 1, Next: nil}
	prev := head
	var newNode *Node
	for i := 2; i <= n; i++ {
		newNode = &Node{Val: i, Next: nil}
		prev.Next = newNode
		prev = newNode
	}
	newNode.Next = head
	count := 0
	curr := head
	var prev2 *Node
	for n > 0 {
		count++
		curr = curr.Next
		if count == m {
			res = append(res, curr.Val)
			prev2 = curr
			curr = curr.Next
			prev2.Next = curr.Next
			n--
			continue
		} else {
			prev2 = curr
			curr = curr.Next
		}
	}
	return res
}
func main() {
	var n, k, m int
	fmt.Scan(&n, &k, &m)
	if n < 0 || k <= 0 || m <= 0 || k > n {
		fmt.Println("Invalid input")
	} else {
		node := &Node{}
		res := node.Jose(n, m)
		for i := 0; i < n; i++ {
			fmt.Printf("%d ", res[i])
		}
	}
}
