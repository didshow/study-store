package main

//func IsPrime(a, b int) []int {
//	var a []int
//
//	for i := a; i <= b; i++ {
//		for j := 0; j <= b; j++ {
//			if i%j != 0 {
//				a = append(a, i)
//			}
//		}
//	}
//}
