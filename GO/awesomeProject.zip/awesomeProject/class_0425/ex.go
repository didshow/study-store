package main

/**
二分查找、冒泡排序、逆序存储；杨辉三角形
*/

func main() {

}

/*
*
二分查找法：必须是排好序的数组
*/
func binarySort(arr []int) {

}
func bubbleSort(arr []int) {

}
func yanghuiTrangle(n int) {

}
