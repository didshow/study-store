package controller

import "errors"

var ErrorConnectClose = errors.New("connect is closed")
