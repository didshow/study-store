# stringx 

## Introduction
Extension/Helper of String Operation.

## Features
- Transform(Reverse, Rotate, Shuffle ...)
- Construction(Pad, Repeat...)
- Matching(IsAlpha, IsAlphanumeric, IsNumeric ...)
