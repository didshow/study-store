package stringx
