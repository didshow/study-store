package log

// package log: 规范日志接口
