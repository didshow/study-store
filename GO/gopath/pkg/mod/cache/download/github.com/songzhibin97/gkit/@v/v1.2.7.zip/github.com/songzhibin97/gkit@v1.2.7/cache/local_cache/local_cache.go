package local_cache

// package local_cache 类似 memcached 构建本地缓存机制
// 具有过期机制且并发安全
