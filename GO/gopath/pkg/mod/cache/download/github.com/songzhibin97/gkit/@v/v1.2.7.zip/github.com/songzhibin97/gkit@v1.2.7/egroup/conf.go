package egroup

import (
	"time"
)

const (
	startTimeout = -1
	stopTimeout  = 20 * time.Second
)
