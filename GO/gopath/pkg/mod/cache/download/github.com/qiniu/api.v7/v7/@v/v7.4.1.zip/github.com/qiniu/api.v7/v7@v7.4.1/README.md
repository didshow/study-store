github.com/qiniu/api.v7 (Qiniu Go SDK v7.x)
===============

[![Build Status](https://travis-ci.org/qiniu/api.v7.svg?branch=master)](https://travis-ci.org/qiniu/api.v7) [![GoDoc](https://godoc.org/github.com/qiniu/api.v7?status.svg)](https://godoc.org/github.com/qiniu/api.v7)

[![Qiniu Logo](http://open.qiniudn.com/logo.png)](http://qiniu.com/)

# 下载

```
go get -u github.com/qiniu/api.v7
```

# go版本需求

需要 go1.10 或者 1.10 以上

#  文档

[七牛SDK文档站](https://developer.qiniu.com/kodo/sdk/1238/go) 或者 [项目WIKI](https://github.com/qiniu/api.v7/wiki)

# 示例

[参考代码](https://github.com/qiniu/api.v7/tree/master/examples)
