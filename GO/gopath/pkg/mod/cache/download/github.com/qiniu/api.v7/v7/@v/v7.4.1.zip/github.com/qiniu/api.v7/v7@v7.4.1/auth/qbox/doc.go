// qbox 包提供了该SDK需要的相关鉴权方法
package qbox
