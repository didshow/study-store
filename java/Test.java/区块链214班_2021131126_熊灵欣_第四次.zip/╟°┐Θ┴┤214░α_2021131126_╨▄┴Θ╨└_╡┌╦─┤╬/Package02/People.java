package Package02;

public class People {
	public void speak() {
		System.out.println("����People");
	}
}
