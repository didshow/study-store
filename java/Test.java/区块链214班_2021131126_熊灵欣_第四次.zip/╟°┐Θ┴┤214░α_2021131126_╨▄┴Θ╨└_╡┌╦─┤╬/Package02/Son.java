package Package02;
import Package01.Father;
public class Son extends Father {
	public String hand;
	public String getHand() {
		return hand;
	}

}
