package Package03;
import Package02.Son;
public class Grandson extends Son {
	public String foot;
}
