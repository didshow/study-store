package Package03;

public class People extends Anthropoid{
	char m = 'A';
	int n = 60;
	void computer(int a,int b) {
		int c = a+b;
		System.out.println(a+"��"+b+"����"+c);
	}
	void crySpeak(String s) {
		System.out.println(m+"**"+s+"**"+m);
	}
}
