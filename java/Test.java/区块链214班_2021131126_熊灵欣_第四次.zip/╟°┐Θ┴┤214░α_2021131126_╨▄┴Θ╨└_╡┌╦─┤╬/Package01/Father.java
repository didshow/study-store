package Package01;
 
public class Father {
		private int money;
		protected int height;
		int weight;
}
