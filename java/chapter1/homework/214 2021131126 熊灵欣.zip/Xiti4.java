class Xiti4{
    public static void main(String args[]){
   	 Speak sp=new Speak();
   	 sp.SpeakHello();
    }
}
