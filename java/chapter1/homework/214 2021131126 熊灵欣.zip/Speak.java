public class Speak{
     void SpeakHello(){
	System.out.println("I'm glad o meet you");
    }
}
