package com.request;

import lombok.Data;

@Data
public class UserReq {
    private String name;
    private String password;
}
